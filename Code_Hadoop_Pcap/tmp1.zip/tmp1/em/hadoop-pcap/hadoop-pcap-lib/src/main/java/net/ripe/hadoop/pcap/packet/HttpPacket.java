package net.ripe.hadoop.pcap.packet;

public class HttpPacket extends Packet {
	private static final long serialVersionUID = -6989112201605879976L;

	public static final String HTTP_HEADERS = "http_headers";
}